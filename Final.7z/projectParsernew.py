import os
import json
from collections import defaultdict


class projectParsernew:
      def __init__(self,location):
         self.location =location
         global files
         global line_count
         global fold
         global dict_of_extensions
         global extensions_of_tech
         global files_with_ext      #dictionary of files accrdng to EXT
         files_with_ext = defaultdict(list)
         files = []
         line_count ={} # dictionary of line count of files
         fold=[]
         for dirName, subdirList, fileList in os.walk(self.location, topdown=False):
             fold.append(dirName)
             for file_name in fileList:
                 files.append(file_name)
                 line_count[file_name]=(len(open(os.path.join(dirName,file_name)).readlines( )))
         dict_of_extensions ={}
         extensions_of_tech ={}
         dict_of_extensions["NoTypeFound"] =0;
         for j in files:
             k = 0    # position of the current letter
             pos = 0  # position of last '.' in the filename 
             for j1 in j:
                 k+=1
                 if j1==".":
                    pos = k
             if pos==0:
                dict_of_extensions["NoTypeFound"]+=1
             else:
                 extension_type = j[pos-1:]
                 files_with_ext[extension_type].append(j);
                 if extension_type in dict_of_extensions.keys():
                    dict_of_extensions[extension_type]+=1
                 else:
                     dict_of_extensions[extension_type] =1
         with open('data.json') as data_file:
              data = json.load(data_file)
         data = data['Application']
         for i in range(0,len(data)):
             extensions_of_tech[data[i]['Technology']] = data[i]['Extn']


      def getTotalFileCount(self):
          return len(files)
      def getCountForFileTypes(self):
          return dict_of_extensions 
      def getLineCount(self):
          return (line_count)
      def getlineCountOfExt(self,tech):
          d2 ={}
          for x in range(0,len(extensions_of_tech[tech])):
              if len(files_with_ext[extensions_of_tech[tech][x]])!=0:
                 for y in range(0,len(files_with_ext[extensions_of_tech[tech][x]])):
                     d2[files_with_ext[extensions_of_tech[tech][x]][y]] = line_count[files_with_ext[extensions_of_tech[tech][x]][y]]
          return d2

