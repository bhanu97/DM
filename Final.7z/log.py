import sys
from collections import defaultdict

f = open("C:\Users\C58717\Desktop\messages","r").readlines()
dicts = defaultdict(list)

for i in f:
    if "INFO" in i:
       dicts["INFO"].append(i)
    elif "WARNING" in i:
         dicts["WARNING"].append(i)
    elif "ERROR" in i:
         dicts["ERROR"].append(i)
    elif "DEBUG" in i:
         dicts["DEBUG"].append(i)
    elif "ERR" in i:
         dicts["ERR"].append(i)
    elif sys.argv[1] in i:
         dicts[sys.argv[1]].append(i)
         
def analyse_log(name):
    print ("Total number of sessions found : "+ str(len(dicts[name])))
    for j in dicts[name]:
        print (j[:15])
        
def analyse_logdetails(name):
    print ("Total number of sessions found : "+ str(len(dicts[name])))
    for j in dicts[name]:
        print (j)    
        
if len(sys.argv)== 2:
   analyse_log(sys.argv[1])        
elif len(sys.argv)==3:
     analyse_logdetails(sys.argv[1])
