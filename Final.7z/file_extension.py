import os
import json
from collections import defaultdict


class projectParsernew:
      def __init__(self,location):
         self.location =location
         self.files_with_ext = defaultdict(list)  #dictionary of files accrdng to EXT
         self.files = []
         self.line_count ={} # dictionary of line count of files
         self.fold=[]
         for dirName, subdirList, fileList in os.walk(self.location, topdown=False):
             self.fold.append(dirName)
             for file_name in fileList:
                 self.files.append(file_name)
                 self.line_count[file_name]=(len(open(os.path.join(dirName,file_name)).readlines( )))
         self.dict_of_extensions ={}
         self.extensions_of_tech ={}
         self.dict_of_extensions["NoTypeFound"] =0;
         for j in self.files:
             k = 0    # position of the current letter
             pos = 0  # position of last '.' in the filename 
             for j1 in j:
                 k+=1
                 if j1==".":
                    pos = k
             if pos==0:
                self.dict_of_extensions["NoTypeFound"]+=1
             else:
                 extension_type = j[pos:]
                 self.files_with_ext[extension_type].append(j);
                 if extension_type in self.dict_of_extensions.keys():
                    self.dict_of_extensions[extension_type]+=1
                 else:
                     self.dict_of_extensions[extension_type] =1


      def getTotalFileCount(self):
          return len(self.files)
      def getCountForFileTypes(self):
          return self.dict_of_extensions 
      def getLineCount(self):
          return (self.line_count)
      def getFilesOfExt(self,tech):
          print self.files_with_ext[tech]

