import cParsertemp_hier

class functionNode:
    def __init__(self,name):
        self.name=name
        self.function_list = []

def hierarchy(function_def):
    cur_function_node = functionNode(function_def)
    for called_function in obj.retrieve_function_calls(function_def):
        called_method = functionNode(called_function)
        if called_function in total_function_list:
           cur_function_node.function_list.append(hierarchy(called_function))
        else:
           cur_function_node.function_list.append(called_method)
                   
    return cur_function_node

def printHierarchy(bac):
    for i in bac.function_list:
        print (i.name)
        if len(i.function_list)!=0:
           print ("------------------------")
           printHierarchy(i)
           print ("************************")


f = open("test.txt","r").read()
obj = cParsertemp_hier.cParserClass()
success = obj.parse_file(f)
print (success)
if success:
    print (obj.retrieve_function_list())
    print (obj.retrieve_function_calls('func'))
    total_function_list = obj.retrieve_function_list()
    bac = hierarchy("main")
    printHierarchy(bac)
   


