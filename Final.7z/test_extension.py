import file_extension
from pprint import pprint

fold_add = raw_input("Enter the location: ")

projectParser1 = file_extension.projectParsernew(fold_add)

results = projectParser1.getTotalFileCount()
print "Total number of files in the directory: "+ str(results)

results1 = projectParser1.getCountForFileTypes()
#pprint(results1)

results2 = projectParser1.getLineCount()
#pprint(results2)

results3 = projectParser1.getFilesOfExt('cpp')
#print(results3)
