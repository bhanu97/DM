from pyparsing import *
from collections import defaultdict



class cParserClass:
      def __init__(self):
          
            expression =Forward()
            statement = Forward()
            constant_expression =Forward()
            compound_statement = Forward()
            declaration =Forward()
            initializer=Forward()
            initializer_list=Forward()
            assignment_expression=Forward()
            declarator=Forward()
            declaration_specifier=Forward()
            enumerator_list=Forward()
            abstract_declarator=Forward()
            direct_abstract_declarator=Forward()
            parameter_type_list=Forward()
            pointer =Forward()
            parameter_list=Forward()
            specifier_qualifier=Forward()
            conditional_expression=Forward()
            enumeration_constant =Forward()
            unary_expression =Forward()
            character_constant =Forward()
            postfix_expression =Forward()
            cast_expression=Forward()
            multiplicative_expression=Forward()
            additive_expression=Forward()
            shift_expression=Forward()
            relational_expression=Forward()
            equality_expression=Forward()
            and_expression=Forward()
            exclusive_or_expression =Forward()
            inclusive_or_expression =Forward()
            direct_declarator=Forward()
            logical_and_expression= Forward()
            logical_or_expression= Forward()
            struct_declarator_list= Forward()
            struct_or_union_specifier =Forward()
            type_specifier= Forward()
            func_call = Forward()

            LPAR,RPAR,LBRACK,RBRACK,LBRACE,RBRACE,SEMI,COMA,EQLTO,LESSTHAN,GRTRTHAN,AMB= map(Suppress, "()[]{};,=<>&")

            INT, CHAR, WHILE, DO, IF, ELSE,FOR, SWITCH,CASE,DEFAULT, RETURN, GOTO, BREAK, CONTINUE,AUTO,REGISTER,STATIC,EXTERN,TYPEDEF = map(Keyword,"int char while do if else for switch case default return goto break continue auto register static extern typedef".split())

            SIZEOF,VOID,CHAR,SHORT,INT,LONG,FLOAT,DOUBLE,SIGNED,UNSIGNED,STRUCT,ENUM,UNION, CONST, VOLATILE = map(Keyword,"sizeof void char short int long float double signed unsigned struct enum union const volatile".split())
                            
            integer_constant = Word(nums)

            floating_constant = Word(nums+'.')

            storage_class_specifier =  (AUTO|REGISTER|STATIC|EXTERN|TYPEDEF)

            header = (Literal('#')+ Literal('include') + LESSTHAN+ Word(alphas)+ Optional(Literal('.h'))+GRTRTHAN)

            identifier = Word(alphas+'_',alphanums+'_') 

            break_continue = BREAK|CONTINUE +SEMI 

            jump_stmnt  = GOTO + identifier + SEMI | BREAK + SEMI | CONTINUE + SEMI | RETURN +Optional(expression) + SEMI 

            iteration_stmnt = (WHILE + LPAR + expression + RPAR + statement) | (DO + statement + WHILE + LPAR + expression + RPAR + SEMI)\
                              | FOR + LPAR + Optional(expression) + SEMI + Optional(expression) + SEMI + Optional(expression) + RPAR + statement

            selection_stmnt = IF + LPAR + expression + RPAR + statement + ELSE + statement | IF + LPAR + expression + RPAR + statement  \
                              | SWITCH + LPAR + expression + RPAR + statement 

            expression_stmnt = (Optional(expression)+SEMI)

            labeled_stmnt = identifier + Literal(':') + statement| CASE + constant_expression + Literal(':') + statement | DEFAULT + Literal(':') + statement

            statement << (labeled_stmnt| jump_stmnt | (expression_stmnt).setResultsName('express')| selection_stmnt| iteration_stmnt | compound_statement)

            compound_statement << (LBRACE + ZeroOrMore((declaration).setResultsName('declaration')|(statement).setResultsName('state')).setResultsName('compmain') + RBRACE)

            initializer_list << initializer + ZeroOrMore(Literal(',') + initializer_list)

            initializer  << (assignment_expression | LBRACE + initializer_list + RBRACE | LBRACE + initializer_list + COMA + RBRACE )

            init_declarator = declarator + Optional( EQLTO + initializer )

            declaration << (OneOrMore(declaration_specifier) + ZeroOrMore(init_declarator + Optional(COMA))+SEMI)

            typedef_name = identifier

            enumerator = identifier + Optional( EQLTO + constant_expression ) 

            enumerator_list << enumerator + ZeroOrMore(Literal(',') + enumerator_list ) 

            enum_specifier = ((ENUM + identifier + LBRACE + enumerator_list + RBRACE) | (ENUM + LBRACE + enumerator_list + RBRACE) | (ENUM + identifier) ).setResultsName('enumerator')

            temp_directabstract = LBRACK + Optional(constant_expression) + RBRACK\
                                  | LPAR + Optional(parameter_type_list) + RPAR

            direct_abstract_declarator << abstract_declarator + ZeroOrMore( temp_directabstract)
                        
            abstract_declarator << ( (pointer + direct_abstract_declarator)| direct_abstract_declarator|pointer)

            parameter_declaration= ZeroOrMore(declaration_specifier)+declarator\
                                      | ZeroOrMore(declaration_specifier)+abstract_declarator\
                                      | ZeroOrMore(declaration_specifier)

            parameter_list<<  parameter_declaration + ZeroOrMore(Literal(',') + parameter_list)

            parameter_type_list<< (parameter_list + Literal(',') |parameter_list)

            type_name = OneOrMore(specifier_qualifier)+ Optional(abstract_declarator)

            unary_operator = Literal('&')|Literal('*')|Literal('+')|Literal('-')|Literal('~')|Literal('!') 

            assignment_operator = Literal('=')|Literal('*=')|Literal('/=')|Literal('%=')|Literal('+=')|Literal('-=')|Literal('<<=')|Literal('>>=')\
                                  |Literal('&=')|Literal('^=')|Literal('!=')
                                   
            assignment_expression << conditional_expression + Optional( assignment_operator) +Optional( assignment_expression ) 

            expression << assignment_expression + ZeroOrMore( Optional(Literal(',')) + expression ) 

            character_constant = Regex(r"'.'")
            
            constant = integer_constant | character_constant | floating_constant| enumeration_constant

            string = Optional(Literal('"'))+ Word(alphanums) + Optional(Literal('"'))

            primary_expression = Group(func_call).setResultsName('calls')|string|constant|identifier| (Literal('(')+expression+Literal(')'))
                   
            temp_postfix = LBRACK+expression+RBRACK \
                           |Literal('(')+ZeroOrMore(assignment_expression)+Literal(')')\
                           |Literal('.')+identifier\
                           |Literal("->")+identifier\
                           |Literal("++")\
                           |Literal("--") 

            postfix_expression<< primary_expression + ZeroOrMore(temp_postfix)  

            unary_expression << (Literal("++")+ unary_expression| Literal("--")+ unary_expression| unary_operator+ cast_expression \
                                      | SIZEOF +LPAR+type_name+RPAR| SIZEOF + unary_expression| postfix_expression) 

            cast_expression << ((LPAR+type_name+RPAR+cast_expression)|unary_expression)

            temp_multiplicative = Literal('*') + multiplicative_expression\
                                  | Literal('/') + multiplicative_expression\
                                  | Literal('%') + multiplicative_expression 

            multiplicative_expression << cast_expression + ZeroOrMore(temp_multiplicative) 

            temp_additive =  Literal('+') + additive_expression\
                            | Literal('-') + additive_expression

            additive_expression << multiplicative_expression +  ZeroOrMore(temp_additive) 

            temp_shift = Literal('<<') + shift_expression\
                         | Literal('>>') + shift_expression 

            shift_expression << additive_expression + ZeroOrMore(temp_shift)

            temp_relational = Literal('<') + relational_expression\
                              | Literal('>') + relational_expression\
                              | Literal('<=') + relational_expression\
                              | Literal('>=') + relational_expression 

            relational_expression << shift_expression + ZeroOrMore(temp_relational) 

            temp_equality = Literal('==') + equality_expression\
                            | Literal('!=') + equality_expression 

            equality_expression << relational_expression + ZeroOrMore(temp_equality) 

            and_expression << equality_expression +  ZeroOrMore(Literal('&') + and_expression) 

            exclusive_or_expression << and_expression + ZeroOrMore( Literal('^') + exclusive_or_expression)

            inclusive_or_expression << exclusive_or_expression + ZeroOrMore( Literal('|')+inclusive_or_expression) 

            logical_and_expression << inclusive_or_expression + ZeroOrMore( Literal('&&') + logical_and_expression) 

            logical_or_expression << logical_and_expression + ZeroOrMore( Literal('||') + logical_or_expression)

            conditional_expression << logical_or_expression + ZeroOrMore( Literal('?')+ expression +Literal(':')+conditional_expression ) 

            constant_expression << conditional_expression

            temp_directdeclarator = LBRACK+Optional(constant_expression)+RBRACK\
                                    |  LPAR + parameter_type_list +  RPAR\
                                    |  LPAR + ZeroOrMore(identifier) + RPAR

            direct_declarator << (identifier |(LPAR+ declarator + RPAR)) + ZeroOrMore(temp_directdeclarator)

            type_qualifier = CONST|VOLATILE

            pointer << Literal('*') + ZeroOrMore(type_qualifier)+ Optional(pointer)                  

            declarator << (Optional(pointer) + direct_declarator)

            struct_declarator_list = ZeroOrMore((struct_or_union_specifier|declarator)+Optional(SEMI|COMA))

            struct_or_union = STRUCT|UNION

            struct_or_union_specifier << (struct_or_union + Optional(identifier)+  Optional(LBRACE + struct_declarator_list + RBRACE))

            type_specifier << (INT|CHAR|SHORT|VOID|LONG|FLOAT|DOUBLE|SIGNED|UNSIGNED| struct_or_union_specifier | enum_specifier)

            declaration_specifier << (storage_class_specifier|type_specifier|type_qualifier)
 
            function_declaration_specifier = ( storage_class_specifier | type_qualifier | INT|CHAR|SHORT|VOID|LONG|FLOAT|DOUBLE)

            function_definition = Group(Optional(function_declaration_specifier).setResultsName('func_decl_spec') + declarator.setResultsName('decl') + compound_statement.setResultsName('comp_stat')).setResultsName('func_name')

            external_declaration = OneOrMore(function_definition|declaration)
            
            translation_unit = (ZeroOrMore(header).setResultsName('headers') + (external_declaration).setResultsName('ext_decl')).setResultsName('trans')

            func_call_param = ZeroOrMore((dblQuotedString|(Optional(AMB)+ expression) ) + Optional(COMA))
                                        
            func_call << (identifier + LPAR + (func_call_param|parameter_list) + RPAR)
      
            self.parser = translation_unit

      def  parse_file(self,fil):
           self.parsed_code = self.parser.parseString(fil)
           return self.parsed_code

      def retrieve_function_list(self):
          x = self.parsed_code['ext_decl'].asList()
          self.y =[]
          self.z = []
          for i in range(0,len(x)):
                if isinstance(x[i],list):
                   self.y.append(i)
                   self.z.append (self.parsed_code['ext_decl'][i]['decl'][0])
          return self.z  

      def retrieve_function_calls(self,funcname):
          dict_func_calls = defaultdict(list)
          for i in self.y:
              k1 = self.parsed_code['ext_decl'][i]['decl'][0]
              k = self.parsed_code['ext_decl'][i].asList()
              for j in range(0,len(k)):
                  if isinstance(k[j],list):
                     dict_func_calls[k1].append(k[j][0])

          return dict_func_calls[funcname]
      
      
        



